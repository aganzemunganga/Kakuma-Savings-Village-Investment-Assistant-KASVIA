# KASVIA — Kakuma Savings & Village Investment Assistant

**An offline-first digital record book for Village Savings and Loans (VSL) groups.**
Built for community savings groups in Kenya, including refugee and host-community groups in Kakuma, where internet is unreliable and paper record books get lost, damaged, or disputed.

[![Tests](https://github.com/YOUR-USERNAME/kasvia/actions/workflows/tests.yml/badge.svg)](../../actions)
![Offline first](https://img.shields.io/badge/offline-first-0F4C41)
![No backend](https://img.shields.io/badge/backend-none-C88A2B)
![License: MIT](https://img.shields.io/badge/license-MIT-blue)

> **Submission for the ReFuTech Hackathon 2026** (virtual build, 26–29 November, Kakuma).
> Live demo: `https://YOUR-USERNAME.github.io/kasvia/` · Pitch deck: [`docs/pitch/KASVIA_Pitch.pptx`](docs/pitch/KASVIA_Pitch.pptx) · Submission notes: [`docs/HACKATHON_SUBMISSION.md`](docs/HACKATHON_SUBMISSION.md)

---

## The problem

A VSL group pools members' savings, lends them out with interest, and shares the pot at the end of a cycle. Most groups run this on a paper notebook and a cash box. That causes real harm:

- **One point of failure.** A lost or wet book erases months of savings history.
- **Manual arithmetic.** Interest, balances and cash counts are worked out by hand at every meeting, so mistakes compound.
- **Weak trust.** Nobody can see who changed a figure, or when, which fuels disputes with the treasurer.
- **No connectivity.** Cloud tools built for city businesses do not work in a camp with patchy internet and limited data budgets.

## The solution

KASVIA replaces the notebook, not the group's own rules. Everything the group already does at a meeting (savings, shares, loans, repayments, fines, welfare, expenses, cash count, attendance) is recorded in a simple app that runs **entirely in the browser, with no server and no internet** once loaded. Data stays on the device.

| | |
|---|---|
| ![Dashboard](docs/screenshots/dashboard.png) | ![Loans](docs/screenshots/loans.png) |
| ![Members](docs/screenshots/members.png) | ![Receipt](docs/screenshots/receipt.png) |

*UI previews rendered with fictional demo data.*

## Features

| Area | Status |
|---|---|
| Three roles: Administrator, Treasurer, Secretary, with role-based permissions | ✅ |
| First-time setup wizard; **no default passwords**, group chooses its own | ✅ |
| Salted PBKDF2-SHA256 password hashing, login lockout, auto-logout | ✅ |
| Second Administrator sign-in for sensitive actions (void, restore, close cycle) | ✅ |
| Members with auto IDs (`VSL-0001`), search by name / ID / phone, statements | ✅ |
| Savings and share purchases (configurable share value) | ✅ |
| Loans: apply → approve → disburse → repay; flat or declining-balance interest; borrowing-limit warning | ✅ |
| Repayments split into principal and interest; Cash or M-Pesa (manual reference code) | ✅ |
| Fines, welfare fund (kept separate from loan funds), group expenses | ✅ |
| Cash reconciliation: expected vs counted cash | ✅ |
| Meetings and attendance register | ✅ |
| Printable receipts and reports; CSV export (opens in Excel) | ✅ |
| Audit log of significant actions; financial records are voided, never deleted | ✅ |
| VSL cycles (start / close) | ✅ |
| Backup and restore (JSON file) with confirmation warning | ✅ |
| Demo mode with fictional members | ✅ |
| Installable PWA (desktop and Android), works offline after first load | ✅ |
| Kiswahili interface | 🛣 Roadmap |
| Multi-device sync | 🛣 Roadmap |
| Encrypted backups, scheduled backups | 🛣 Roadmap |
| Direct PDF export (use browser *Print → Save as PDF* today) | 🛣 Roadmap |
| Automatic M-Pesa API integration | ❌ Not claimed. M-Pesa codes are typed in manually |

## Quick start

### Option A: use the hosted demo (easiest, installs on phones)
Open `https://YOUR-USERNAME.github.io/kasvia/` once with internet. The page is served over HTTPS, so the browser offers **Install**; after that the app opens and works with no internet at all.

### Option B: run it fully offline on a laptop
```bash
git clone https://github.com/YOUR-USERNAME/kasvia.git
cd kasvia
# Windows: double-click scripts/Start_KASVIA_Windows.bat
# macOS/Linux: ./scripts/Start_KASVIA_Mac_Linux.sh
# or, with Python 3:
python3 -m http.server 8080 --directory app      # then open http://localhost:8080
```
No build step and no dependencies are needed to *run* the app.

### First use
1. Open the app and complete the setup wizard (group name, savings and loan rules, create the three accounts with your own passwords).
2. Click **Load demo data** on the dashboard to explore with fictional members, or start entering real records.
3. Make a backup from **Backup & Restore** regularly.

## How it works

```mermaid
flowchart LR
  U[Treasurer / Secretary / Admin] --> UI[Single-page UI<br/>vanilla JS]
  UI --> RBAC[Role permissions<br/>+ admin re-auth]
  RBAC --> LOGIC[Loan, interest and cash logic]
  LOGIC --> DB[(IndexedDB<br/>on the device)]
  UI --> SW[Service worker<br/>cache-first]
  SW -. offline assets .-> UI
  DB --> BK[Backup file<br/>JSON]
```

- **No backend, no cloud, no tracking.** Vanilla HTML/CSS/JS, no frameworks, no CDN calls.
- **IndexedDB** holds every record locally; **Web Crypto** hashes passwords.
- **Service worker** caches the app so it loads with no connection; **web manifest** makes it installable.

More detail: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) · [`docs/SECURITY.md`](docs/SECURITY.md)

## Important design limits (read before real use)

- **Data lives in the browser of the device it is entered on.** Each device has its own separate database; there is no sync yet. Use **one primary device per group** and move data with Backup & Restore.
- Clearing the browser's site data deletes the database. **Back up regularly.**
- Backups are plain JSON (not encrypted). Store them safely.
- This is a protection against mistakes and casual tampering, not against a person with full technical access to the device. See [`docs/SECURITY.md`](docs/SECURITY.md).
- Pilot with demo data and a real group meeting before relying on it.

## Tests

```bash
npm install
npm test
```
10 automated tests run the real app code (interest maths, password hashing, ID generation, database export/import, role permissions, "no network calls") in Node. See [`docs/TEST_REPORT.md`](docs/TEST_REPORT.md) for what is and is not yet covered.

## Project structure

```
kasvia/
├── app/                 # the entire application (static files)
│   ├── index.html       # shell + styles
│   ├── db.js            # IndexedDB wrapper
│   ├── auth.js          # roles, sessions, lockout
│   ├── util.js          # IDs, hashing, audit log, formatting
│   ├── loans.js         # loans, interest, repayments
│   ├── modules.js       # members, savings, fines, welfare, expenses
│   ├── reports.js       # reports and search
│   ├── main.js          # dashboard, meetings, cash, cycles, backup, users, settings
│   ├── install.js       # install prompt
│   ├── sw.js            # service worker (offline)
│   └── manifest.json    # PWA manifest + icons/
├── docs/                # user manual (Word + Markdown), pitch deck, architecture, security, tests
├── scripts/             # one-click launchers (Windows, macOS/Linux)
├── tests/               # automated tests
└── .github/workflows/   # CI tests + GitHub Pages deploy
```

## Roadmap

1. Kiswahili interface (language switch).
2. Device-to-device sync over local WiFi and QR/file transfer.
3. Encrypted and scheduled backups.
4. Android wrapper (TWA/Capacitor) for Play Store distribution.
5. Donor and partner reporting for savings groups.
6. M-Pesa message import (parse confirmation SMS text) while staying offline.

## Contributing and license

Issues and pull requests are welcome; see [`CONTRIBUTING.md`](CONTRIBUTING.md). Released under the [MIT License](LICENSE).

Built by **[YOUR NAME]** for the ReFuTech Hackathon 2026.
